import json
from dataclasses import dataclass, asdict
from typing import List, Optional
import random
from datetime import datetime

@dataclass
class Email:
    """Класс для представления электронного письма"""
    id: int
    sender: str
    subject: str
    content: str
    date: str
    read: bool = False
    important: bool = False
    
    def to_dict(self) -> dict:
        """Преобразовать письмо в словарь"""
        return {
            "id": self.id,
            "sender": self.sender,
            "subject": self.subject,
            "content": self.content,
            "date": self.date,
            "read": self.read,
            "important": self.important
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Email':
        """Создать письмо из словаря"""
        return cls(
            id=data.get("id", 0),
            sender=data.get("sender", ""),
            subject=data.get("subject", ""),
            content=data.get("content", ""),
            date=data.get("date", ""),
            read=data.get("read", False),
            important=data.get("important", False)
        )


class EmailSystem:
    """Система управления почтой"""
    
    def __init__(self, player_name: str = "", day: int = 1, reputation: int = 0, money: float = 0.0):
        self.player_name = player_name
        self.day = day
        self.reputation = reputation
        self.money = money
        
        self.inbox: List[Email] = []
        self.sent: List[Email] = []
        self.draft: List[Email] = []
        
        self.next_email_id = 1
        self.unread_emails = 0
        self.emails_received_today = False
        self.mvd_email_read = False
        
        # НОВОЕ: отслеживание отправки специальных писем
        self.special_emails_sent = {
            "error_message": False,  # Флаг для письма ERROR
            # Здесь можно добавлять другие специальные письма
        }
        
        # Загрузка шаблонов писем
        self._load_email_templates()
    
    def _load_email_templates(self):
        """Загрузка шаблонов писем"""
        self.email_templates = {
            "system_welcome": {
                "sender": "МВД",
                "subject": "Добро пожаловать!",
                "template": """От: МВД-ЦУК
Кому: {player_name}
Тема: Добро пожаловать!

Уважаемый {player_name}!

Приветствуем вас на почётной должности Оперативно-Поискового Управления!

Ваши успехи в учёбе нас впечатлили, и мы хотели бы предложить вам эту позицию. 
Надеемся на вашу ответственность и качественную работу.

Это ваши показатели:
Текущий день работы: {day}
Ваша текущая репутация: {reputation}
Ваш баланс: {money:,.2f} ₽

От вас ожидается ответственное отношение к обязанностям для успешного выполнения работы.
Мы уверены, что вы справитесь и оправдаете наши ожидания.

В ближайшее время вы получите перечень текущих задач. 
На первом этапе предлагаем ознакомиться с рабочим местом и коллективом.

Наблюдение — наша функция. Ваша осведомлённость — ваша обязанность.
ПРОЕКТ «ПАНОПТИКУМ». МЫ ВСЁ ВИДИМ.

С уважением,
Центр управления кадрами МВД"""
            },
            "error_message": {
                "sender": "ERROR",
                "subject": "ERROR",
                "template": """От: ERROR
Кому: ERROR
Тема: ERROR

ERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERROR
ERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERROR
ERRORERRORERRORERROR

"""
            },
#if email_type == "my_custom_email":
    # Ваши особые условия
    #required_tasks = condition_data.get("required_tasks", 2)
    #required_time = condition_data.get("required_time", 120)
    
    # Дополнительные условия (например, проверка навыка)
    #has_skill = condition_data.get("has_hacking_skill", False)
    
    #if (condition_data.get("tasks_completed", 0) >= required_tasks and 
        #shift_time >= required_time and
        #has_skill):
        #return self.send_special_email(email_type)
            "system_notification": {
                "sender": "Система",
                "subject": "Уведомление",
                "template": """От: {sender}
Кому: {player_name}
Тема: {subject}

{message}

[Это автоматическое сообщение системы]"""
            },
            "mvd_mission": {
                "sender": "МВД",
                "subject": "СРОЧНО: Задание от МВД",
                "template": """От: МВД-ОПУ
Кому: {player_name}
Тема: СРОЧНО: Задание от МВД

Сотрудник {player_name}!

Вам назначено срочное задание. 
Требуется выполнить его в кратчайшие сроки.

Задание: {mission_name}
Сложность: {difficulty}
Срок: {deadline}

Описание: {description}

В случае успешного выполнения ожидается повышение репутации и денежное вознаграждение.

Наблюдение — наша функция. Ваша осведомлённость — ваша обязанность.

С уважением,
Отдел по особым поручениям МВД"""
            }
        }
    
    def add_email(self, sender: str, subject: str, content: str, important: bool = False) -> int:
        """Добавить новое письмо"""
        email = Email(
            id=self.next_email_id,
            sender=sender,
            subject=subject,
            content=content,
            date=self._get_current_time(),
            read=False,
            important=important
        )
        
        self.inbox.append(email)
        self.next_email_id += 1
        
        if not email.read:
            self.unread_emails += 1
        
        # Проверяем, является ли это письмо от МВД
        if email.sender == "МВД":
            self.mvd_email_read = False
        
        return email.id
    
    def add_template_email(self, template_name: str, **kwargs) -> int:
        """Добавить письмо из шаблона"""
        if template_name not in self.email_templates:
            raise ValueError(f"Шаблон '{template_name}' не найден")
        
        template = self.email_templates[template_name]
        
        # Заполняем стандартные переменные
        kwargs.setdefault("player_name", self.player_name)
        kwargs.setdefault("day", self.day)
        kwargs.setdefault("reputation", self.reputation)
        kwargs.setdefault("money", self.money)
        
        # Форматируем контент
        content = template["template"].format(**kwargs)
        
        # Определяем важность письма
        important = template_name == "mvd_mission"
        
        return self.add_email(
            sender=template["sender"],
            subject=template["subject"],
            content=content,
            important=important
        )
    
    def get_emails(self, folder: str = "inbox") -> List[Email]:
        """Получить письма из указанной папки"""
        if folder == "inbox":
            return self.inbox
        elif folder == "sent":
            return self.sent
        elif folder == "draft":
            return self.draft
        else:
            raise ValueError(f"Неизвестная папка: {folder}")
    
    def get_email_by_id(self, email_id: int) -> Optional[Email]:
        """Найти письмо по ID"""
        for email in self.inbox + self.sent + self.draft:
            if email.id == email_id:
                return email
        return None
    
    def mark_as_read(self, email_id: int) -> bool:
        """Пометить письмо как прочитанное"""
        email = self.get_email_by_id(email_id)
        if email and not email.read:
            email.read = True
            self.unread_emails -= 1
            
            if email.sender == "МВД":
                self.mvd_email_read = True
            
            return True
        return False
    
    def mark_as_unread(self, email_id: int) -> bool:
        """Пометить письмо как непрочитанное"""
        email = self.get_email_by_id(email_id)
        if email and email.read:
            email.read = False
            self.unread_emails += 1
            return True
        return False
    
    def delete_email(self, email_id: int) -> bool:
        """Удалить письмо"""
        # Ищем во всех папках
        for folder in [self.inbox, self.sent, self.draft]:
            for i, email in enumerate(folder):
                if email.id == email_id:
                    if not email.read:
                        self.unread_emails -= 1
                    del folder[i]
                    return True
        return False
    
    def move_to_folder(self, email_id: int, folder: str) -> bool:
        """Переместить письмо в другую папку"""
        email = self.get_email_by_id(email_id)
        if not email:
            return False
        
        # Удаляем из текущей папки
        self.delete_email(email_id)
        
        # Добавляем в новую папку
        if folder == "inbox":
            self.inbox.append(email)
        elif folder == "sent":
            self.sent.append(email)
        elif folder == "draft":
            self.draft.append(email)
        else:
            return False
        
        return True
    
    def get_unread_count(self) -> int:
        """Получить количество непрочитанных писем"""
        return self.unread_emails
    
    def get_total_count(self) -> int:
        """Получить общее количество писем"""
        return len(self.inbox) + len(self.sent) + len(self.draft)
    
    def clear_old_emails(self, days_old: int = 7):
        """Очистить старые письма"""
        # Пока просто очищаем все, кроме важных
        self.inbox = [email for email in self.inbox if email.important]
        self.sent = [email for email in self.sent if email.important]
        self.unread_emails = len([email for email in self.inbox if not email.read])
        
        # НОВОЕ: сбрасываем флаги отправки специальных писем для нового дня
        self.special_emails_sent = {key: False for key in self.special_emails_sent}
        self.emails_received_today = False
    
    def send_email(self, to: str, subject: str, body: str) -> bool:
        """Отправить письмо"""
        # В текущей версии игры игрок не отправляет письма
        # Этот метод зарезервирован для будущих расширений
        return False
    
    def add_initial_emails(self):
        """Добавить начальные письма"""
        self.clear_old_emails()
        
        # Письмо от МВД
        self.add_template_email("system_welcome")
        
        # Загадочное письмо ERROR (не отправляем сразу, только при выполнении условий)
        # self.add_template_email("error_message") - НЕ ДОБАВЛЯЕМ СРАЗУ
        
        # Системное уведомление
        self.add_email(
            sender="Система",
            subject="Системное уведомление",
            content="""Добро пожаловать в систему мониторинга МВД.
Все ваши действия записываются и анализируются.
Соблюдайте правила безопасности и поддерживайте лояльность.
Не забывайте отмечать письма кнопкой «ПРОЧИТАНО»!
(После прочтения можете удалить это письмо)""",
            important=False
        )
        
        self.emails_received_today = True
    
    def generate_daily_emails(self):
        """Сгенерировать ежедневные письма"""
        if not self.emails_received_today:
            self.add_initial_emails()
        
        # Случайное письмо (30% шанс)
        if random.random() < 0.3:
            spam_senders = ["Реклама", "Спам", "Непрочитанное", "Уведомление"]
            spam_subjects = [
                "Спецпредложение только для вас!",
                "Ваш аккаунт был взломан",
                "Срочно: проверьте безопасность",
                "Новое обновление системы"
            ]
            
            self.add_email(
                sender=random.choice(spam_senders),
                subject=random.choice(spam_subjects),
                content="Это тестовое сообщение. Не отвечайте на него.",
                important=False
            )
    
    def add_mission_email(self, mission_name: str, difficulty: str, deadline: str, description: str):
        """Добавить письмо с заданием"""
        return self.add_template_email(
            "mvd_mission",
            mission_name=mission_name,
            difficulty=difficulty,
            deadline=deadline,
            description=description
        )
    
    def add_system_notification(self, message: str, important: bool = False):
        """Добавить системное уведомление"""
        return self.add_email(
            sender="Система",
            subject="Системное уведомление",
            content=f"{message}\n\n[Это автоматическое сообщение системы]",
            important=important
        )
    
    # НОВЫЕ МЕТОДЫ ДЛЯ УПРАВЛЕНИЯ СПЕЦИАЛЬНЫМИ ПИСЬМАМИ
    
    def check_and_send_special_email(self, email_type: str, shift_time: int, condition_data: dict) -> bool:
        """
        Проверить условия и отправить специальное письмо
        
        Args:
            email_type: тип письма (например, "error_message")
            shift_time: игровое время в минутах
            condition_data: словарь с данными для проверки условий
                Например: {"tasks_completed": 1, "required_time": 60}
        """
        # Проверяем, существует ли такой тип письма
        if email_type not in self.email_templates:
            print(f"[ОШИБКА] Тип письма '{email_type}' не найден в шаблонах")
            return False
        
        # Проверяем, не отправлялось ли уже это письмо сегодня
        if self.special_emails_sent.get(email_type, False):
            return False
        
        # Проверяем условия (базовый пример для письма ERROR)
        if email_type == "error_message":
            # Условия для письма ERROR:
            # 1. Выполнена хотя бы одна задача
            # 2. Прошло определенное время (по умолчанию 60 минут)
            required_tasks = condition_data.get("tasks_completed", 1)
            required_time = condition_data.get("required_time", 60)
            
            # Проверяем условия
            if condition_data.get("tasks_completed", 0) >= required_tasks and shift_time >= required_time:
                # Отправляем письмо
                return self.send_special_email(email_type)
        
        # Здесь можно добавлять проверки для других типов писем
        # elif email_type == "другой_тип":
        #     ...
        
        return False
    
    def send_special_email(self, email_type: str) -> bool:
        """Отправить специальное письмо"""
        if email_type not in self.email_templates:
            print(f"[ОШИБКА] Тип письма '{email_type}' не найден")
            return False
        
        if self.special_emails_sent.get(email_type, False):
            print(f"[ИНФО] Письмо '{email_type}' уже отправлено сегодня")
            return False
        
        # Отправляем письмо
        self.add_template_email(email_type)
        
        # Помечаем как отправленное
        self.special_emails_sent[email_type] = True
        
        print(f"[ПОЧТА] Отправлено специальное письмо: {email_type}")
        return True
    
    def add_custom_template(self, template_name: str, sender: str, subject: str, template: str):
        """Добавить пользовательский шаблон письма"""
        self.email_templates[template_name] = {
            "sender": sender,
            "subject": subject,
            "template": template
        }
        print(f"[ПОЧТА] Добавлен новый шаблон: {template_name}")
    
    def _get_current_time(self) -> str:
        """Получить текущее время"""
        return datetime.now().strftime("%H:%M")
    
    def to_dict(self) -> dict:
        """Преобразовать систему в словарь для сохранения"""
        return {
            "inbox": [email.to_dict() for email in self.inbox],
            "sent": [email.to_dict() for email in self.sent],
            "draft": [email.to_dict() for email in self.draft],
            "next_email_id": self.next_email_id,
            "unread_emails": self.unread_emails,
            "emails_received_today": self.emails_received_today,
            "mvd_email_read": self.mvd_email_read,
            "special_emails_sent": self.special_emails_sent,  # НОВОЕ: сохраняем флаги
            "player_name": self.player_name,
            "day": self.day,
            "reputation": self.reputation,
            "money": self.money
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'EmailSystem':
        """Создать систему из словаря"""
        email_system = cls(
            player_name=data.get("player_name", ""),
            day=data.get("day", 1),
            reputation=data.get("reputation", 0),
            money=data.get("money", 0.0)
        )
        
        email_system.next_email_id = data.get("next_email_id", 1)
        email_system.unread_emails = data.get("unread_emails", 0)
        email_system.emails_received_today = data.get("emails_received_today", False)
        email_system.mvd_email_read = data.get("mvd_email_read", False)
        email_system.special_emails_sent = data.get("special_emails_sent", {"error_message": False})  # НОВОЕ
        
        # Восстанавливаем письма
        for email_data in data.get("inbox", []):
            email_system.inbox.append(Email.from_dict(email_data))
        
        for email_data in data.get("sent", []):
            email_system.sent.append(Email.from_dict(email_data))
        
        for email_data in data.get("draft", []):
            email_system.draft.append(Email.from_dict(email_data))
        
        return email_system
    
    def __repr__(self) -> str:
        return f"EmailSystem(player={self.player_name}, emails={self.get_total_count()}, unread={self.unread_emails})"