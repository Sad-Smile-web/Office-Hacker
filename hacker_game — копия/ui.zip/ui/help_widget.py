# ui/help_widget.py
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, 
                               QLabel, QPushButton, QFrame, QTextBrowser, 
                               QTabWidget, QScrollArea)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

class HelpWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)
        
        # Заголовок
        title = QLabel("📖 ПОМОЩЬ ПО ИГРЕ")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("""
            font-size: 28px;
            font-weight: bold;
            color: #00bfff;
            text-shadow: 0 0 10px #00bfff, 0 0 20px rgba(0, 191, 255, 0.5);
            margin-bottom: 20px;
        """)
        
        # Создаем вкладки
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 2px solid #00bfff;
                background-color: #0a0a0a;
                border-radius: 5px;
            }
            QTabBar::tab {
                background-color: #002244;
                color: #00bfff;
                padding: 10px 20px;
                border: 1px solid #00bfff;
                margin-right: 2px;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background-color: #004488;
                color: #ffffff;
                border-bottom: none;
            }
            QTabBar::tab:hover {
                background-color: #003366;
            }
        """)
        
        # Вкладка "Основы"
        basics_tab = QWidget()
        basics_layout = QVBoxLayout()
        basics_text = """
        <div style="font-family: 'Arial', sans-serif; line-height: 1.6; color: #cccccc;">
        
        <h2 style="color: #00bfff;">🎮 ОСНОВЫ ИГРЫ</h2>
        
        <p><b>«Офисный Хакер»</b> — это симулятор работы в сфере кибербезопасности компании <b>«СИБИРЬ-СОФТ»</b>.</p>
        
        <h3 style="color: #00ff88;">ЦЕЛЬ ИГРЫ:</h3>
        <ul>
            <li>Выполняйте ежедневные задания для продвижения по карьерной лестнице</li>
            <li>Развивайте навыки кибербезопасности</li>
            <li>Зарабатывайте деньги (рубли) и повышайте репутацию</li>
            <li>Избегайте обнаружения системой безопасности</li>
        </ul>
        
        <h3 style="color: #00ff88;">ИНТЕРФЕЙС:</h3>
        <p>Игровой интерфейс состоит из трех основных панелей:</p>
        <ul>
            <li><span style="color: #00bfff;">Левая панель</span> - информация о сотруднике, баланс, репутация, текущая задача и навыки</li>
            <li><span style="color: #00bfff;">Центральная панель</span> - терминал для выполнения команд</li>
            <li><span style="color: #00bfff;">Правая панель</span> - камера наблюдения и лог системы безопасности</li>
        </ul>
        
        <h3 style="color: #00ff88;">НАЧАЛО ИГРЫ:</h3>
        <ol>
            <li>Начните новую смену через главное меню</li>
            <li>Введите ваше имя и фамилию при регистрации</li>
            <li>Выполните первую задачу "Загляните в "ПОЧТУ""</li>
            <li>Используйте терминал для выполнения заданий</li>
        </ol>
        
        </div>
        """
        
        basics_browser = QTextBrowser()
        basics_browser.setHtml(basics_text)
        basics_browser.setOpenExternalLinks(True)
        basics_browser.setStyleSheet("""
            QTextBrowser {
                background-color: #0a0a0a;
                border: 1px solid #333;
                border-radius: 5px;
                padding: 15px;
                color: #cccccc;
                font-family: 'Arial', sans-serif;
                font-size: 14px;
            }
            QScrollBar:vertical {
                background: #001122;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #00bfff;
                min-height: 20px;
                border-radius: 6px;
            }
        """)
        basics_layout.addWidget(basics_browser)
        basics_tab.setLayout(basics_layout)
        
        # Вкладка "Терминал"
        terminal_tab = QWidget()
        terminal_layout = QVBoxLayout()
        terminal_text = """
        <div style="font-family: 'Arial', sans-serif; line-height: 1.6; color: #cccccc;">
        
        <h2 style="color: #00ff00;">⌨️ КОМАНДЫ ТЕРМИНАЛА</h2>
        
        <h3 style="color: #00ff88;">ОСНОВНЫЕ КОМАНДЫ:</h3>
        <table border="1" cellpadding="10" cellspacing="0" style="border-collapse: collapse; width: 100%;">
        <tr style="background-color: #002200;">
            <th style="color: #00ff00; text-align: left;">Команда</th>
            <th style="color: #00ff00; text-align: left;">Описание</th>
            <th style="color: #00ff00; text-align: left;">Пример</th>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">help</code></td>
            <td>Показать список всех команд</td>
            <td><code>help</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">scan</code></td>
            <td>Сканировать сеть на наличие устройств</td>
            <td><code>scan</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">connect [IP]</code></td>
            <td>Подключиться к устройству по IP-адресу</td>
            <td><code>connect 192.168.1.1</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">hack [цель]</code></td>
            <td>Взломать указанную цель</td>
            <td><code>hack server1</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">tasks</code></td>
            <td>Показать текущие задания</td>
            <td><code>tasks</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">clear</code></td>
            <td>Очистить экран терминала</td>
            <td><code>clear</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">dir</code></td>
            <td>Показать файлы в текущем каталоге</td>
            <td><code>dir</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">ipconfig</code></td>
            <td>Показать сетевые настройки</td>
            <td><code>ipconfig</code></td>
        </tr>
        <tr>
            <td><code style="color: #00ffff;">whoami</code></td>
            <td>Информация о текущем пользователе</td>
            <td><code>whoami</code></td>
        </tr>
        </table>
        
        <h3 style="color: #00ff88;">СОВЕТЫ ПО ИСПОЛЬЗОВАНИЮ:</h3>
        <ul>
            <li>Используйте <span style="color: #00ffff;">Tab</span> для автодополнения команд</li>
            <li>Стрелки <span style="color: #00ffff;">↑</span> и <span style="color: #00ffff;">↓</span> для навигации по истории команд</li>
            <li>Все команды чувствительны к регистру</li>
            <li>Для получения справки по конкретной команде введите <code>команда --help</code></li>
        </ul>
        
        </div>
        """
        
        terminal_browser = QTextBrowser()
        terminal_browser.setHtml(terminal_text)
        terminal_browser.setStyleSheet(basics_browser.styleSheet())
        terminal_layout.addWidget(terminal_browser)
        terminal_tab.setLayout(terminal_layout)
        
        # Вкладка "Управление"
        controls_tab = QWidget()
        controls_layout = QVBoxLayout()
        controls_text = """
        <div style="font-family: 'Arial', sans-serif; line-height: 1.6; color: #cccccc;">
        
        <h2 style="color: #ffff00;">🎮 УПРАВЛЕНИЕ И ГОРЯЧИЕ КЛАВИШИ</h2>
        
        <h3 style="color: #ffaa00;">ГОРЯЧИЕ КЛАВИШИ:</h3>
        <table border="1" cellpadding="10" cellspacing="0" style="border-collapse: collapse; width: 100%;">
        <tr style="background-color: #332200;">
            <th style="color: #ffff00; text-align: left;">Клавиша</th>
            <th style="color: #ffff00; text-align: left;">Действие</th>
            <th style="color: #ffff00; text-align: left;">Описание</th>
        </tr>
        <tr>
            <td><kbd style="background: #444; padding: 3px 6px; border-radius: 3px;">F1</kbd></td>
            <td>Помощь</td>
            <td>Открыть это окно помощи</td>
        </tr>
        <tr>
            <td><kbd style="background: #444; padding: 3px 6px; border-radius: 3px;">ESC</kbd></td>
            <td>Меню</td>
            <td>Вернуться в главное меню</td>
        </tr>
        <tr>
            <td><kbd style="background: #444; padding: 3px 6px; border-radius: 3px;">Ctrl + S</kbd></td>
            <td>Сохранить</td>
            <td>Быстрое сохранение игры</td>
        </tr>
        <tr>
            <td><kbd style="background: #444; padding: 3px 6px; border-radius: 3px;">Ctrl + L</kbd></td>
            <td>Загрузить</td>
            <td>Быстрая загрузка игры</td>
        </tr>
        <tr>
            <td><kbd style="background: #444; padding: 3px 6px; border-radius: 3px;">Ctrl + Q</kbd></td>
            <td>Выход</td>
            <td>Выйти из игры</td>
        </tr>
        <tr>
            <td><kbd style="background: #444; padding: 3px 6px; border-radius: 3px;">Tab</kbd></td>
            <td>Автодополнение</td>
            <td>Автодополнение команд в терминале</td>
        </tr>
        <tr>
            <td><kbd style="background: #444; padding: 3px 6px; border-radius: 3px;">↑ / ↓</kbd></td>
            <td>История</td>
            <td>Навигация по истории команд</td>
        </tr>
        </table>
        
        <h3 style="color: #ffaa00;">ИНТЕРФЕЙС:</h3>
        <ul>
            <li><b>Левая кнопка мыши</b> - выбор элементов интерфейса</li>
            <li><b>Правая кнопка мыши</b> - контекстное меню (где доступно)</li>
            <li><b>Колесико мыши</b> - прокрутка списков и текста</li>
            <li><b>Enter</b> - подтверждение ввода в терминале</li>
        </ul>
        
        <h3 style="color: #ffaa00;">НАСТРОЙКИ УПРАВЛЕНИЯ:</h3>
        <p>Все горячие клавиши можно переназначить в настройках игры.</p>
        
        </div>
        """
        
        controls_browser = QTextBrowser()
        controls_browser.setHtml(controls_text)
        controls_browser.setStyleSheet(basics_browser.styleSheet())
        controls_layout.addWidget(controls_browser)
        controls_tab.setLayout(controls_layout)
        
        # Вкладка "Навыки"
        skills_tab = QWidget()
        skills_layout = QVBoxLayout()
        skills_text = """
        <div style="font-family: 'Arial', sans-serif; line-height: 1.6; color: #cccccc;">
        
        <h2 style="color: #ff55ff;">🎯 СИСТЕМА НАВЫКОВ</h2>
        
        <p>Навыки определяют вашу эффективность в различных аспектах работы. Уровень навыка от 1 до 10.</p>
        
        <h3 style="color: #ff88ff;">ОПИСАНИЕ НАВЫКОВ:</h3>
        <table border="1" cellpadding="10" cellspacing="0" style="border-collapse: collapse; width: 100%;">
        <tr style="background-color: #330033;">
            <th style="color: #ff55ff; text-align: left;">Навык</th>
            <th style="color: #ff55ff; text-align: left;">Описание</th>
            <th style="color: #ff55ff; text-align: left;">Как повысить</th>
        </tr>
        <tr>
            <td><span style="color: #ff5555; font-weight: bold;">Взлом</span></td>
            <td>Способность взламывать системы, обходить защиту</td>
            <td>Выполнение заданий по взлому, использование терминала</td>
        </tr>
        <tr>
            <td><span style="color: #55ff55; font-weight: bold;">Социальная инженерия</span></td>
            <td>Умение манипулировать сотрудниками для получения доступа</td>
            <td>Взаимодействие с NPC, выполнение социальных заданий</td>
        </tr>
        <tr>
            <td><span style="color: #5555ff; font-weight: bold;">Программирование</span></td>
            <td>Создание скриптов, утилит и эксплойтов</td>
            <td>Написание кода в терминале, решение программистских задач</td>
        </tr>
        <tr>
            <td><span style="color: #ffff55; font-weight: bold;">Скрытность</span></td>
            <td>Умение избегать обнаружения системой безопасности</td>
            <td>Выполнение заданий без обнаружения, использование скрытых команд</td>
        </tr>
        <tr>
            <td><span style="color: #55ffff; font-weight: bold;">Анализ</span></td>
            <td>Способность анализировать данные и находить уязвимости</td>
            <td>Анализ логов, исследование сетевых пакетов</td>
        </tr>
        <tr>
            <td><span style="color: #ffaa55; font-weight: bold;">Сетевая безопасность</span></td>
            <td>Знание сетевых протоколов и технологий защиты</td>
            <td>Настройка сетевого оборудования, защита систем</td>
        </tr>
        </table>
        
        <h3 style="color: #ff88ff;">УРОВНИ НАВЫКОВ:</h3>
        <ul>
            <li><span style="color: #ff5555;">1-3: Новичок</span> - Базовые знания</li>
            <li><span style="color: #ffff55;">4-6: Опытный</span> - Хорошее понимание</li>
            <li><span style="color: #55ff55;">7-8: Эксперт</span> - Профессиональный уровень</li>
            <li><span style="color: #55ffff;">9-10: Мастер</span> - Высший уровень мастерства</li>
        </ul>
        
        <h3 style="color: #ff88ff;">СОВЕТЫ:</h3>
        <ul>
            <li>Сбалансированно развивайте все навыки</li>
            <li>Сложные задания дают больше опыта</li>
            <li>Некоторые задания требуют минимального уровня навыков</li>
            <li>Высокий уровень навыков открывает новые возможности</li>
        </ul>
        
        </div>
        """
        
        skills_browser = QTextBrowser()
        skills_browser.setHtml(skills_text)
        skills_browser.setStyleSheet(basics_browser.styleSheet())
        skills_layout.addWidget(skills_browser)
        skills_tab.setLayout(skills_layout)
        
        # Добавляем вкладки
        self.tabs.addTab(basics_tab, "Основы")
        self.tabs.addTab(terminal_tab, "Терминал")
        self.tabs.addTab(controls_tab, "Управление")
        self.tabs.addTab(skills_tab, "Навыки")
        
        # Кнопка возврата
        back_btn = QPushButton("🔙 НАЗАД В МЕНЮ")
        back_btn.clicked.connect(self.go_back)
        back_btn.setMinimumHeight(45)
        back_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #006600, stop:0.5 #004400, stop:1 #002200);
                color: #00ff00;
                border: 2px solid #00ff00;
                padding: 12px;
                font-size: 14px;
                font-weight: bold;
                min-height: 45px;
                border-radius: 8px;
                text-align: center;
                letter-spacing: 1px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #008800, stop:0.5 #006600, stop:1 #004400);
                border-color: #ffff00;
                color: #ffff00;
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #002200, stop:0.5 #001100, stop:1 #000000);
            }
        """)
        
        layout.addWidget(title)
        layout.addWidget(self.tabs, 1)
        layout.addWidget(back_btn)
        
        self.setLayout(layout)
        
    def go_back(self):
        """Вернуться в меню"""
        if self.parent:
            self.parent.show_menu()