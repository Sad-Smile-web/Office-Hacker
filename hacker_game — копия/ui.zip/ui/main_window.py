import sys
import os
import json
from pathlib import Path
from PySide6.QtWidgets import QMainWindow, QStackedWidget, QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton
from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QIcon

from ui.menu_widget import MenuWidget
from ui.game_widget import GameWidget
from ui.about_widget import AboutWidget
from ui.help_widget import HelpWidget
from ui.settings_widget import SettingsWidget
from core.game_state import GameState
from audio_manager import AudioManager
import random

class NameInputDialog(QDialog):
    """Диалог для ввода имени и фамилии"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Регистрация сотрудника")
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(15)
        
        # Заголовок
        title = QLabel("РЕГИСТРАЦИЯ НОВОГО СОТРУДНИКА")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("""
            font-size: 18px;
            font-weight: bold;
            color: #cccccc;
            margin-bottom: 20px;
        """)
        
        # Поля ввода
        name_layout = QHBoxLayout()
        name_label = QLabel("Имя:")
        name_label.setMinimumWidth(80)
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Введите ваше имя")
        name_layout.addWidget(name_label)
        name_layout.addWidget(self.name_input)
        
        surname_layout = QHBoxLayout()
        surname_label = QLabel("Фамилия:")
        surname_label.setMinimumWidth(80)
        self.surname_input = QLineEdit()
        self.surname_input.setPlaceholderText("Введите вашу фамилию")
        surname_layout.addWidget(surname_label)
        surname_layout.addWidget(self.surname_input)
        
        # Кнопки
        button_layout = QHBoxLayout()
        self.ok_btn = QPushButton("ПОДТВЕРДИТЬ")
        self.ok_btn.clicked.connect(self.accept)
        self.ok_btn.setEnabled(False)
        self.cancel_btn = QPushButton("ОТМЕНА")
        self.cancel_btn.clicked.connect(self.reject)
        
        button_layout.addWidget(self.ok_btn)
        button_layout.addWidget(self.cancel_btn)
        
        # Валидация ввода
        self.name_input.textChanged.connect(self.validate_input)
        self.surname_input.textChanged.connect(self.validate_input)
        
        # Добавление виджетов
        layout.addWidget(title)
        layout.addLayout(name_layout)
        layout.addLayout(surname_layout)
        layout.addStretch()
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        self.setMinimumWidth(400)
        
    def validate_input(self):
        """Проверка заполнения полей"""
        name = self.name_input.text().strip()
        surname = self.surname_input.text().strip()
        self.ok_btn.setEnabled(bool(name) and bool(surname))
        
    def get_name(self):
        """Получить введенные имя и фамилию"""
        return self.name_input.text().strip(), self.surname_input.text().strip()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = self.load_config()
        self.game_state = GameState()
        self.audio_manager = AudioManager()
        self.init_ui()
        self.setup_window()
        
    def load_config(self):
        """Загрузить конфигурацию"""
        default_config = {
            "game": {
                "difficulty": 2,
                "autosave_interval": 300,
                "enable_tutorial": True,
                "language": "ru"
            },
            "graphics": {
                "enable_effects": True,
                "glitch_effects": True,
                "window_width": 1200,
                "window_height": 800,
                "display_mode": "fullscreen",
                "vsync": True,
                "effect_intensity": 70
            },
            "audio": {
                "enabled": True,
                "volume": 70,
                "typing_sounds": True,
                "background_music": True,
                "effects_volume": 80,
                "music_volume": 60,
                "master_volume": 70,
                "voice_effects": True,
                "environment_sounds": True,
                "dynamic_range": "normal"
            },
            "game_time": {
                "time_speed": 1.0,
                "real_time_seconds_per_game_minute": 10,  # 10 реальных секунд = 1 игровая минута
                "auto_pause_in_menus": True,
                "show_time_widget": True
            }
        }
        
        try:
            if os.path.exists("config.json"):
                with open("config.json", "r", encoding="utf-8") as f:
                    loaded_config = json.load(f)
                    # Объединяем с дефолтными значениями
                    for category in default_config:
                        if category in loaded_config:
                            # Обновляем только существующие ключи
                            for key in loaded_config[category]:
                                if key in default_config[category]:
                                    default_config[category][key] = loaded_config[category][key]
                            
                    # Сохраняем для обратной совместимости с меню
                    if "fullscreen" in loaded_config.get("game", {}):
                        # Преобразуем старое значение в новый формат
                        fullscreen = loaded_config["game"]["fullscreen"]
                        default_config["graphics"]["display_mode"] = "fullscreen" if fullscreen else "windowed"
        except Exception as e:
            print(f"Ошибка загрузки конфига: {e}")
        
        return default_config
        
    def init_ui(self):
        # Центральный виджет - стек для переключения экранов
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)
        
        # Виджет меню
        self.menu_widget = MenuWidget(self)
        self.menu_widget.show_settings.connect(self.show_settings)
        self.menu_widget.show_help.connect(self.show_help)
        self.menu_widget.show_about.connect(self.show_about)
        self.menu_widget.start_game.connect(self.start_new_game)
        self.menu_widget.load_game.connect(self.load_game)
        self.menu_widget.exit_game.connect(self.close)
        self.stacked_widget.addWidget(self.menu_widget)
        
        # Виджет "О программе"
        self.about_widget = AboutWidget(self)
        self.stacked_widget.addWidget(self.about_widget)
        
        # Виджет "Помощь"
        self.help_widget = HelpWidget(self)
        self.stacked_widget.addWidget(self.help_widget)
        
        # Виджет настроек
        self.settings_widget = SettingsWidget(self, self.config)
        self.settings_widget.back_to_menu.connect(self.show_menu)
        self.settings_widget.settings_changed.connect(self.on_settings_changed)
        self.stacked_widget.addWidget(self.settings_widget)
        
        # Виджет игры (сначала пустой)
        self.game_widget = None
        
        # Таймер для обновления игрового времени
        self.game_time_timer = None
        
    def setup_window(self):
        """Настройка окна"""
        self.setWindowTitle("ОФИСНЫЙ ХАКЕР - СИМУЛЯТОР КИБЕРБЕЗОПАСНОСТИ")
        
        # Устанавливаем размер окна из конфига
        width = self.config["graphics"]["window_width"]
        height = self.config["graphics"]["window_height"]
        self.setGeometry(100, 100, width, height)
        
        # Полноэкранный режим из конфига
        display_mode = self.config["graphics"]["display_mode"]
        if display_mode == "fullscreen":
            self.showFullScreen()
        elif display_mode == "windowed":
            self.showNormal()
        elif display_mode == "borderless":
            self.showNormal()
            self.setWindowFlags(Qt.FramelessWindowHint)
            self.show()
        else:
            self.showMaximized()
            
        self.setMinimumSize(800, 600)
        
        # Установка иконки
        try:
            self.setWindowIcon(QIcon("assets/icons/hack_icon.png"))
        except:
            pass
            
    def show_settings(self):
        """Показать экран настроек"""
        # Обновляем конфиг в виджете настроек
        self.settings_widget.config = self.config
        # Обновляем UI настроек
        self.update_settings_widget_ui()
        self.stacked_widget.setCurrentWidget(self.settings_widget)
        self.audio_manager.click_sound()
        
    def update_settings_widget_ui(self):
        """Обновить UI виджета настроек"""
        # Обновляем все элементы UI в settings_widget
        # Графика
        self.settings_widget.effects_check.setChecked(self.config["graphics"]["enable_effects"])
        self.settings_widget.glitch_check.setChecked(self.config["graphics"]["glitch_effects"])
        self.settings_widget.vsync_check.setChecked(self.config["graphics"]["vsync"])
        
        # Интенсивность эффектов
        intensity = self.config["graphics"].get("effect_intensity", 70)
        self.settings_widget.intensity_slider.setValue(intensity)
        self.settings_widget.intensity_value.setText(f"{intensity}%")
        
        # Режим отображения
        display_mode = self.config["graphics"]["display_mode"]
        if display_mode == "fullscreen":
            self.settings_widget.display_combo.setCurrentIndex(0)
        elif display_mode == "windowed":
            self.settings_widget.display_combo.setCurrentIndex(1)
        elif display_mode == "borderless":
            self.settings_widget.display_combo.setCurrentIndex(2)
        
        # Разрешение
        current_res = f"{self.config['graphics']['window_width']}x{self.config['graphics']['window_height']}"
        if current_res in [self.settings_widget.resolution_combo.itemText(i) for i in range(self.settings_widget.resolution_combo.count())]:
            self.settings_widget.resolution_combo.setCurrentText(current_res)
        else:
            self.settings_widget.resolution_combo.addItem(current_res)
            self.settings_widget.resolution_combo.setCurrentText(current_res)
        
        # Аудио
        self.settings_widget.audio_check.setChecked(self.config["audio"]["enabled"])
        self.settings_widget.volume_slider.setValue(self.config["audio"]["volume"])
        self.settings_widget.volume_value.setText(f"{self.config['audio']['volume']}%")
        
        self.settings_widget.master_volume_slider.setValue(self.config["audio"]["master_volume"])
        self.settings_widget.master_volume_value.setText(f"{self.config['audio']['master_volume']}%")
        
        self.settings_widget.typing_sounds_check.setChecked(self.config["audio"]["typing_sounds"])
        self.settings_widget.music_check.setChecked(self.config["audio"]["background_music"])
        
        self.settings_widget.effects_volume_slider.setValue(self.config["audio"]["effects_volume"])
        self.settings_widget.effects_volume_value.setText(f"{self.config['audio']['effects_volume']}%")
        
        self.settings_widget.music_volume_slider.setValue(self.config["audio"]["music_volume"])
        self.settings_widget.music_volume_value.setText(f"{self.config['audio']['music_volume']}%")
        
        self.settings_widget.voice_check.setChecked(self.config["audio"]["voice_effects"])
        self.settings_widget.environment_check.setChecked(self.config["audio"]["environment_sounds"])
        
        # Динамический диапазон
        dynamic_range = self.config["audio"]["dynamic_range"]
        if dynamic_range == "normal":
            self.settings_widget.dynamic_range_combo.setCurrentText("Нормальный")
        elif dynamic_range == "wide":
            self.settings_widget.dynamic_range_combo.setCurrentText("Широкий")
        elif dynamic_range == "night":
            self.settings_widget.dynamic_range_combo.setCurrentText("Ночной режим")
        
        # Игровое время (если есть соответствующие виджеты в settings_widget)
        if hasattr(self.settings_widget, 'time_speed_slider'):
            time_speed = self.config["game_time"]["time_speed"]
            self.settings_widget.time_speed_slider.setValue(int(time_speed * 10))
            self.settings_widget.time_speed_value.setText(f"{time_speed:.1f}x")
            
    def on_settings_changed(self, new_config):
        """Обработчик изменения настроек"""
        # Обновляем только настройки графики, аудио и времени
        self.config["graphics"] = new_config["graphics"]
        self.config["audio"] = new_config["audio"]
        
        if "game_time" in new_config:
            self.config["game_time"] = new_config["game_time"]
            
            # Обновляем скорость времени в игровом состоянии
            if hasattr(self, 'game_state') and self.game_state:
                self.game_state.game_time['time_speed'] = self.config["game_time"]["time_speed"]
        
        # Обновляем аудио менеджер
        self.audio_manager.update_settings(self.config)
        
        # Применяем графические настройки
        self.apply_graphics_settings()
        
        # Обновляем эффекты в меню
        if hasattr(self, 'menu_widget'):
            self.menu_widget.config = self.config
            self.menu_widget.update_effects()
        
    def apply_graphics_settings(self):
        """Применить настройки графики"""
        # Применяем режим отображения
        display_mode = self.config["graphics"]["display_mode"]
        
        if display_mode == "fullscreen":
            if not self.isFullScreen():
                self.showFullScreen()
        elif display_mode == "windowed":
            if self.isFullScreen():
                self.showNormal()
            # Убираем frameless если был
            self.setWindowFlags(self.windowFlags() & ~Qt.FramelessWindowHint)
            self.show()
        elif display_mode == "borderless":
            if self.isFullScreen():
                self.showNormal()
            self.setWindowFlags(Qt.FramelessWindowHint)
            self.show()
                
        # Применяем размер окна
        width = self.config["graphics"]["window_width"]
        height = self.config["graphics"]["window_height"]
        
        if not self.isFullScreen():
            current_width = self.width()
            current_height = self.height()
            
            if current_width != width or current_height != height:
                # Центрируем окно
                screen = self.screen().availableGeometry()
                x = (screen.width() - width) // 2
                y = (screen.height() - height) // 2
                self.setGeometry(x, y, width, height)
        
    def start_new_game(self):
        """Начать новую игру"""
        # Звук клика
        self.audio_manager.click_sound()
        
        # Запрашиваем имя и фамилию
        dialog = NameInputDialog(self)
        if dialog.exec() == QDialog.Accepted:
            first_name, last_name = dialog.get_name()
            self.game_state = GameState()
            self.game_state.first_name = first_name
            self.game_state.last_name = last_name
            self.game_state.player_name = f"{first_name} {last_name}"
            
            # Устанавливаем скорость времени из конфига
            if "game_time" in self.config:
                self.game_state.game_time['time_speed'] = self.config["game_time"]["time_speed"]
            
            self.game_state.start_shift()
            self.show_game()
        
    def load_game(self):
        """Загрузить сохранение"""
        try:
            self.game_state = GameState.load()
            if not self.game_state.shift_started:
                self.game_state.start_shift()
            
            # Устанавливаем скорость времени из конфига
            if "game_time" in self.config:
                self.game_state.game_time['time_speed'] = self.config["game_time"]["time_speed"]
            
            self.show_game()
            self.audio_manager.success_sound()
        except:
            QMessageBox.warning(self, "Ошибка", "Сохранение не найдено!")
            self.audio_manager.error_sound()
            
    def show_about(self):
        """Показать информацию о программе"""
        self.stacked_widget.setCurrentWidget(self.about_widget)
        self.audio_manager.click_sound()
        
    def show_help(self):
        """Показать справку"""
        self.stacked_widget.setCurrentWidget(self.help_widget)
        self.audio_manager.click_sound()
        
    def show_game(self):
        """Показать игровой экран"""
        if self.game_widget:
            self.stacked_widget.removeWidget(self.game_widget)
            self.game_widget.deleteLater()
            
        self.game_widget = GameWidget(self.game_state)
        self.game_widget.back_to_menu.connect(self.show_menu)
        self.stacked_widget.addWidget(self.game_widget)
        self.stacked_widget.setCurrentWidget(self.game_widget)
        self.audio_manager.success_sound()
        
        # Запускаем/перезапускаем таймер игрового времени
        self.setup_game_time_timer()
        
    def setup_game_time_timer(self):
        """Настройка таймера для обновления игрового времени"""
        # Останавливаем старый таймер, если он есть
        if self.game_time_timer:
            self.game_time_timer.stop()
        
        # Создаем новый таймер
        self.game_time_timer = QTimer()
        
        # Настраиваем интервал из конфига
        interval = self.config["game_time"].get("real_time_seconds_per_game_minute", 10) * 1000
        self.game_time_timer.setInterval(interval)
        
        # Подключаем обработчик
        self.game_time_timer.timeout.connect(self.update_game_time)
        
        # Запускаем таймер
        if self.game_state and self.game_state.shift_started:
            self.game_time_timer.start()
        
    def update_game_time(self):
        """Обновить игровое время"""
        if (hasattr(self, 'game_state') and 
            self.game_state and 
            hasattr(self.game_state, 'game_time') and
            self.game_state.shift_started and
            not self.game_state.game_time.get('is_paused', False)):
            
            # Получаем скорость времени из конфига или game_state
            time_speed = self.game_state.game_time.get('time_speed', 1.0)
            
            # Обновляем время с учетом скорости
            minutes_to_add = int(time_speed)
            if minutes_to_add < 1:
                # Для скоростей меньше 1 накапливаем дробные минуты
                if not hasattr(self, '_time_accumulator'):
                    self._time_accumulator = 0.0
                
                self._time_accumulator += time_speed
                if self._time_accumulator >= 1.0:
                    minutes_to_add = 1
                    self._time_accumulator -= 1.0
                else:
                    minutes_to_add = 0
            
            if minutes_to_add > 0:
                # Обновляем время в game_state
                self.game_state.update_time(minutes_to_add)
                
                # Проверяем окончание рабочего дня
                if self.game_state.game_time['current_hour'] >= 18:
                    # Окончание рабочего дня
                    self.end_workday()
                
                # Обновляем UI в виджете игры
                if hasattr(self, 'game_widget') and self.game_widget:
                    self.game_widget.update_ui()
                    
                    # Обновляем виджет времени, если он есть
                    if hasattr(self.game_widget, 'time_widget'):
                        self.game_widget.time_widget.update_display()
                    
                    # Проверяем специальные письма
                    self.game_state.check_special_emails()
        
    def end_workday(self):
        """Окончание рабочего дня"""
        if not hasattr(self, 'game_state') or not self.game_state:
            return
        
        # Выплачиваем бонус за смену
        shift_bonus = self.game_state.tasks_completed * 1000
        self.game_state.money += shift_bonus
        
        # Показываем уведомление
        QMessageBox.information(
            self, 
            "Конец рабочего дня", 
            f"Рабочий день завершен!\n"
            f"Выполнено задач: {self.game_state.tasks_completed}\n"
            f"Вы получили бонус: {shift_bonus:,.2f} ₽\n"
            f"Переход ко дню {self.game_state.day + 1}"
        )
        
        # Завершаем смену
        self.game_state.end_shift()
        
        # Обновляем UI
        if hasattr(self, 'game_widget') and self.game_widget:
            self.game_widget.update_ui()
            if hasattr(self.game_widget, 'time_widget'):
                self.game_widget.time_widget.update_display()
        
    def show_menu(self):
        """Показать меню"""
        if self.game_widget:
            # Сохраняем игру
            self.game_state.save()
            self.audio_manager.click_sound()
            
            # Приостанавливаем игровое время, если настроено
            if self.config["game_time"].get("auto_pause_in_menus", True):
                if self.game_state:
                    self.game_state.pause_game_time()
        
        # Останавливаем таймер времени
        if self.game_time_timer and self.game_time_timer.isActive():
            self.game_time_timer.stop()
        
        self.stacked_widget.setCurrentWidget(self.menu_widget)
        
    def closeEvent(self, event):
        """Сохранить при закрытии"""
        # Звук закрытия
        self.audio_manager.click_sound()
        
        # Автосохранение при выходе
        if self.config.get("user", {}).get("autosave_on_exit", True):
            if hasattr(self, 'game_state') and self.game_state.shift_started:
                try:
                    self.game_state.save()
                    print("[АВТОСОХРАНЕНИЕ] Игра сохранена при выходе")
                except Exception as e:
                    print(f"[ОШИБКА] Не удалось сохранить игру: {e}")
        
        # Останавливаем все таймеры
        if hasattr(self, 'popup_timer'):
            self.popup_timer.stop()
            
        if hasattr(self, 'game_time_timer') and self.game_time_timer:
            self.game_time_timer.stop()
            
        # Сохраняем конфиг
        try:
            with open("config.json", "w", encoding="utf-8") as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Ошибка сохранения конфига: {e}")
        
        event.accept()
        
    def keyPressEvent(self, event):
        """Обработка горячих клавиш"""
        # Звук печати при вводе
        if event.text().isprintable() and len(event.text()) > 0:
            self.audio_manager.typing_sound()
        
        if event.key() == Qt.Key_F1:
            self.show_help()
        elif event.key() == Qt.Key_Escape:
            self.show_menu()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_S:
            if hasattr(self, 'game_state') and self.game_state.shift_started:
                self.game_state.save()
                QMessageBox.information(self, "Сохранение", "Игра сохранена!")
                self.audio_manager.success_sound()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_Q:
            self.close()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_F:
            # Переключение полноэкранного режима
            current_mode = self.config["graphics"]["display_mode"]
            if current_mode == "fullscreen":
                self.config["graphics"]["display_mode"] = "windowed"
            else:
                self.config["graphics"]["display_mode"] = "fullscreen"
            self.apply_graphics_settings()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_M:
            # Отключение звука
            self.config["audio"]["enabled"] = not self.config["audio"]["enabled"]
            self.audio_manager.update_settings(self.config)
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_T:
            # Пауза/возобновление игрового времени
            if hasattr(self, 'game_state') and self.game_state:
                if self.game_state.game_time.get('is_paused', False):
                    self.game_state.resume_game_time()
                    if self.game_time_timer and not self.game_time_timer.isActive():
                        self.game_time_timer.start()
                    print("[ВРЕМЯ] Игровое время возобновлено")
                else:
                    self.game_state.pause_game_time()
                    if self.game_time_timer and self.game_time_timer.isActive():
                        self.game_time_timer.stop()
                    print("[ВРЕМЯ] Игровое время приостановлено")
        else:
            super().keyPressEvent(event)
            
    def resizeEvent(self, event):
        """Обработка изменения размера окна"""
        super().resizeEvent(event)
        
        # Сохраняем размер окна в конфиг, если не в полноэкранном режиме
        if not self.isFullScreen():
            self.config["graphics"]["window_width"] = self.width()
            self.config["graphics"]["window_height"] = self.height()